﻿using System;

partial class Program
{
	static void Zad6()
	{
        int s;
        s = 0;
        Console.WriteLine("Zad.6");
        for (int i = 0; i <= 100; i++)
        {
            s = s + i;

        }
        Console.WriteLine(s);
    }
}
