﻿using System;

partial class Program
{
	static void Zad2()
	{
        Console.WriteLine("Zad.2");
        int i;
		i = 0;
		do {
			Console.WriteLine(i * 3);
			i++;
		}
		while (i <= 10);
	}
}
