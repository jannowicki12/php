﻿using System;

partial class Program
{
	static void Zad4()
	{
        Console.WriteLine("Zad.4");
        int i;
        i = 0;
        do
        {
            Console.WriteLine(i);
            i++;
        }
        while (i <= 20);
    }
}
