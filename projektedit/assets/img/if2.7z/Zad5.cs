﻿using System;

partial class Program
{
	static void Zad5()
	{
        Console.WriteLine("Zad.5");
        int i;
        i = 0;
        
        while (i <= 20)
        {
            Console.WriteLine(i);
            i++;
        }
        
    }
}
