﻿using System;

partial class Program
{
	static void Zad3()
	{
        Console.WriteLine("Zad.3");
        for (int i = 0; i <= 20; i++)
        {
            Console.WriteLine(i);
        }
    }
}
