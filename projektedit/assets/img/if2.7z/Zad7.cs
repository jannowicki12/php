﻿using System;

partial class Program
{
	static void Zad7()
	{
        Console.WriteLine("Zad.7");
        int s = 0,i = 0;



        do
        {
            s = s + i;
            i++;
        }
        while (i <= 100);
        Console.WriteLine(s);
    }
}
