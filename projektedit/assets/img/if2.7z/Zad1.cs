﻿using System;

partial class Program
{
	static void Zad1()
	{
		Console.WriteLine("Zad.1");
		for (int i=0; i <= 10; i++)
		{
			Console.WriteLine(i * 3);
		}
	}
}
