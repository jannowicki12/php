﻿using System;

partial class Program
{
    static void Main(string[] args)
    {
        Zad1();
        Zad2();
        Zad3();
        Zad4();
        Zad5();
        Zad6();
        Zad7();
        Zad8();
    }
}