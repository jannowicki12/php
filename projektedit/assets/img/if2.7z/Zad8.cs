﻿using System;

partial class Program
{
    static void Zad8()
    {
        Console.WriteLine("Zad.7");
        int s = 0, i = 0;



        while (i <= 100)
        {
            s = s + i;
            i++;
        }
        Console.WriteLine(s);
    }
}